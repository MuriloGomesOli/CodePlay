// src/components/CodeEditor.tsx
import React, { useState } from 'react';
import styles from '../../styles/jogo.module.css';
import codeLogo from '../../assets/logo.png';

interface CodeEditorProps {
  welcomeText: string;        // Texto de boas-vindas
  instructionText: string;    // Instrução principal
  codeExample: string;        // Código inicial no textarea
  hintText?: string;          // Dica opcional
  mainButtonText?: string;    // Texto do botão principal
  onNext?: () => void;        // Callback do botão PROXIMO
}

const CodeEditor: React.FC<CodeEditorProps> = ({
  welcomeText,
  instructionText,
  codeExample,
  hintText,
  mainButtonText = 'CODEPLAY',
  onNext,
}) => {
  const [showHint, setShowHint] = useState(false);

  return (
    <div className={styles.codeCard}>
      {/* Seção de boas-vindas */}
      <div className={styles.welcomeSection}>
        <img src={codeLogo} alt="Code Play Logo" className={styles.codeLogo} />
        <p className={styles.welcomeText}>{welcomeText}</p>
      </div>

      {/* Instrução principal */}
      <div className={styles.instruction} dangerouslySetInnerHTML={{ __html: instructionText }} />

      {/* Área do editor de código */}
      <div className={styles.editorArea}>
        <span className={styles.lineNumber}>1</span>
        <textarea className={styles.codeTextarea} defaultValue={codeExample}></textarea>
      </div>

      {/* Dica + botões */}
      <div className={styles.hintSection}>
        {showHint && hintText && (
          <>
            <div className={styles.hintBox} dangerouslySetInnerHTML={{ __html: hintText }} />
            <div className={styles.arrow}></div>
          </>
        )}

        <div className={styles.buttonGroup}>
          {hintText && (
            <button
              className={`${styles.actionButton} ${styles.hintButton}`}
              onClick={() => setShowHint(!showHint)}
            >
              {showHint ? 'OCULTAR' : 'DICA'}
            </button>
          )}

          <button
            className={`${styles.actionButton} ${styles.nextButton}`}
            onClick={onNext}
          >
            PROXIMO
          </button>
        </div>
      </div>

      {/* Botão principal */}
      <button className={styles.codePlayButton}>{mainButtonText}</button>
    </div>
  );
};

export default CodeEditor;
